a=input("Enter a number:")
a=int(a)
#Any number divided by 2 and remainder is 0 is even
if a%2==0:
    print("It is even number")
else:
    print("It is not even number")