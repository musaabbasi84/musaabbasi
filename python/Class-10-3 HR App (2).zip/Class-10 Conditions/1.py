#take input from user
a=input("Enter a number:")
b=input("Enter another number:")
c=int(a)+int(b) 
print(c)
