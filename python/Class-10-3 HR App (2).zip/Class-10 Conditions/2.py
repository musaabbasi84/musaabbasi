#Take input from user
name=input("Enter name:")
age=input("Enter age:")
print(name)
print(age)
