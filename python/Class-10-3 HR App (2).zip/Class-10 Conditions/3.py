#take input from user
vowel1=input("Enter vowel1:")
vowel2=input("Enter vowel2:")
vowel3=input("Enter vowel3:")
vowel4=input("Enter vowel4:")
vowel5=input("Enter vowel5:")
print(vowel1)
print(vowel2)
print(vowel3)
print(vowel4)
print(vowel5)




