#it will give error
numbers1=(10,20,30,40,50)
numbers2=(60,70,80,90,100)


print(numbers1-numbers2)