'''
Program-4:Find 3rd element of list
'''
numbers=(10,20,30,40,50)
print(numbers[2])
