#Replace 30 with 200, it will give error
numbers=(10,20,30,40,50)
numbers[2]=200
print(numbers)
