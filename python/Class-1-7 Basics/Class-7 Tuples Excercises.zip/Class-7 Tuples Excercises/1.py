'''
Program-1:Find First Element Of List
'''
numbers=(1,2,3,4,5)
#tuple has 5 indexes 0 to 4
#First element is located on index 0 of list

print(str(numbers[0]))
