t=(1,2,3,"Ali")
print(t)
print(t[0])