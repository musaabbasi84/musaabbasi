fruits = ("apple", "banana", "orange", "kiwi", "grape")
reversed_fruits = tuple(reversed(fruits))
print("Reversed list:", reversed_fruits)

